package com.ppcpl.main.Service;

import java.util.List;

import com.ppcpl.main.Entities.Registered_Employees;

public interface Registered_Employees_Service {

	public void addEmployee(Registered_Employees registerEmp);
	
	public void EditEmployee(Registered_Employees registerEmp ,String name );
	
	public List<Registered_Employees> getAllEmployees();
	
	public List<Registered_Employees> getEmployeeByFirstName(String fname);
}
