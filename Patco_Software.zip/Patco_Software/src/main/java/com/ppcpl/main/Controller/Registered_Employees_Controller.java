package com.ppcpl.main.Controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ppcpl.main.DTO.RegisteredEmployeeDTO;
import com.ppcpl.main.Entities.Registered_Employees;
import com.ppcpl.main.Service.Registered_Employees_Service;

import jakarta.validation.Valid;

@RestController
public class Registered_Employees_Controller {
	
	@Autowired
	Registered_Employees_Service service;

	/*@GetMapping("getAllEmployee")
	public List<Registered_Employees> getAllEmployees(){
		return service.getAllEmployees();
	}
	
	@GetMapping("getByName/{fname}")
	public List<Registered_Employees> findEmployeeByFirstName( @PathVariable  String fname) {
	    return service.getEmployeeByFirstName(fname);
	}
*/
	
	 @GetMapping("getAllEmployee")
	    public List<RegisteredEmployeeDTO> getAllEmployees() {
	        return service.getAllEmployees().stream()
	                .map(emp -> new RegisteredEmployeeDTO(emp.getFirstName(), emp.getLastName(), emp.getUserName(), emp.getPassword(), emp.getDepartment(), emp.getDataAddedDate()))
	                .collect(Collectors.toList());
	    }

	    @GetMapping("getByName/{fname}")
	    public List<RegisteredEmployeeDTO> findEmployeeByFirstName(@PathVariable String fname) {
	        return service.getEmployeeByFirstName(fname).stream()
	                .map(emp -> new RegisteredEmployeeDTO(emp.getFirstName(), emp.getLastName(), emp.getUserName(), emp.getPassword(), emp.getDepartment(), emp.getDataAddedDate()))
	                .collect(Collectors.toList());
	    }

	
	@PutMapping("editEmployee/{name}")
	public void editEmployeeData(@RequestBody Registered_Employees registerEmp, @PathVariable String name) {
		service.EditEmployee(registerEmp, name);
	}
	
	@PostMapping("addEmployee")
	public void addEmployee( @RequestBody Registered_Employees registerEmp) {
		service.addEmployee(registerEmp);
	}
	
	
}
