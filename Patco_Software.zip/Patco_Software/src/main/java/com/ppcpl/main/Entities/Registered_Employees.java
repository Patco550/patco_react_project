package com.ppcpl.main.Entities;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore; // Import for hiding field in JSON responses

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

@Entity
public class Registered_Employees {

    @Id
    @Column(name = "FIRST_NAME")
    private String firstName;

    @Column(name = "LAST_NAME")
    private String lastName;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "DEPARTMENT")
    private String department;

    @Column(name = "DATA_ADDED_DATE", updatable = false) // Fixed column name
    @JsonIgnore
    private LocalDateTime dataAddedDate;

    @PrePersist
    protected void onCreate() {
        if (dataAddedDate == null) {
            dataAddedDate = LocalDateTime.now();
        }
    }

   
    public LocalDateTime getDataAddedDate() {
        return dataAddedDate;
    }

    public void setDataAddedDate(LocalDateTime dataAddedDate) {
        this.dataAddedDate = dataAddedDate;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public Registered_Employees(String firstName, String lastName, LocalDateTime dataAddedDate, String userName,
                                String password, String department) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dataAddedDate = dataAddedDate;
        this.userName = userName;
        this.password = password;
        this.department = department;
    }

    public Registered_Employees() {
    }

    @Override
    public String toString() {
        return "Registered_Employees [firstName=" + firstName + ", lastName=" + lastName
                + ", dataAddedDate=" + dataAddedDate + ", userName=" + userName + ", password=" + password
                + ", department=" + department + "]";
    }
}
