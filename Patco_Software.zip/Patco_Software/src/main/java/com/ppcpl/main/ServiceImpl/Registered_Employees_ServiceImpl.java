package com.ppcpl.main.ServiceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ppcpl.main.Entities.Registered_Employees;
import com.ppcpl.main.Exception.EmployeeNotFoundException;
import com.ppcpl.main.Repository.Registered_Employees_Repository;
import com.ppcpl.main.Service.Registered_Employees_Service;

@Service
public class Registered_Employees_ServiceImpl implements Registered_Employees_Service {

	@Autowired
	Registered_Employees_Repository registerRepo;
	
	   @Override
	    public void addEmployee(Registered_Employees registerEmp) {
	        registerEmp.setDataAddedDate(LocalDateTime.now());
	        registerRepo.save(registerEmp);
	    }
	
	    @Override
	    public void EditEmployee(Registered_Employees registerEmp, String name) {
	        List<Registered_Employees> employees = registerRepo.findByFirstName(name);

	        if (employees.isEmpty()) {
	            throw new EmployeeNotFoundException("No employee found with first name: " + name);
	        }

	        for (Registered_Employees employee : employees) {
	            employee.setDataAddedDate(LocalDateTime.now()); // Update the date on edit if needed
	            employee.setUserName(registerEmp.getUserName());
	            employee.setFirstName(registerEmp.getFirstName());
	            employee.setLastName(registerEmp.getLastName());
	            employee.setPassword(registerEmp.getPassword());
	            employee.setDepartment(registerEmp.getDepartment());

	            registerRepo.save(employee);
	        }
	    }


	@Override
	public List<Registered_Employees> getAllEmployees() {
		return registerRepo.findAll();
	}


	@Override
	public List<Registered_Employees> getEmployeeByFirstName(String fname) {
	    return registerRepo.findByFirstName(fname);
	}


	
	
	
	
}
